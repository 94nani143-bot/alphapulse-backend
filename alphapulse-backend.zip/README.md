# AlphaPulse Backend

This is the backend server for the AlphaPulse app providing real-time trade signal data.

## How to Run

1. Install dependencies:
```
npm install
```

2. Start server:
```
node server.js
```

The API will be live at: `http://localhost:3000/api/signals`