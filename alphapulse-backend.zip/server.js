const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

app.get('/api/signals', (req, res) => {
  const { symbol = 'INFY', timeframe = '5min', strategy = 'breakout' } = req.query;

  const mockSignals = {
    market: symbol.includes('BTC') ? '🪙 Crypto Market (Delta Exchange)' : '📈 Indian Stocks (Angel One)',
    description: `${timeframe} Signals using ${strategy} strategy`,
    signals: [
      `Buy ${symbol.toUpperCase()} above 3450 | Target: 3480 | SL: 3430`,
      `Sell ${symbol.toUpperCase()} below 3400 | Target: 3370 | SL: 3420`
    ]
  };

  res.json([mockSignals]);
});

app.listen(PORT, () => {
  console.log(`AlphaPulse API running on port ${PORT}`);
});